"""Repeated sensor-selected pickup skills in one robot's calibrated workcell."""

from __future__ import annotations

import math
from types import SimpleNamespace

import numpy as np
from warehouse.physics import RobotController, observation
from warehouse.physics_jobs_sensors import JobSensorBelief
from warehouse.representation import Entity


class RepeatedJobController(RobotController):
    """Select a fresh sensed parcel, reset the arm, then walk/reach again.

    Each observer continuously updates its own color-conditioned posterior.
    Completed parcels remain in the same physical world throughout later jobs.
    """

    def __init__(self, index, local, shared, offset, session, cfg, **kwargs):
        super().__init__(index, local, shared, offset, session, cfg, **kwargs)
        self.observer.close()
        self.observers = {
            job: JobSensorBelief(
                local,
                shared,
                self.id + "/",
                offset,
                job=job,
                sensor_interventions=self.scenario["sensors"],
                noise_seed=self.scenario["seed"] + index,
            )
            for job in ("a", "b")
        }
        self.current_job = "a"
        self.observer = self.observers["a"]
        self.job_sensors = {}
        self.completed_jobs = []
        self.reset_started = None
        self.reset_joints = None
        self.transit_waypoints = []

    def observe(self, data):
        self.job_sensors = {
            job: observer.observe(data) for job, observer in self.observers.items()
        }
        self.observer = self.observers[self.current_job]
        self.sensed = self.job_sensors[self.current_job]
        return self.sensed

    def scene_entities(self, now):
        entities = []
        for job, sensed in self.job_sensors.items():
            for kind, key, agekey, color in [
                (
                    "parcel",
                    "object_position",
                    "object_measurement_age_s",
                    "orange" if job == "a" else "green",
                ),
                (
                    "receiver",
                    "destination_position",
                    "destination_measurement_age_s",
                    "magenta" if job == "a" else "blue",
                ),
            ]:
                if sensed[key] is not None and sensed[agekey] is not None:
                    entities.append(
                        Entity(
                            f"{kind}_{self.index}_{job}",
                            "parcel" if kind == "parcel" else "station",
                            {"color": color, "lane": str(self.index), "job": job},
                            tuple(sensed[key]),
                            now - sensed[agekey],
                            f"{self.id}/{job}/shared_rgbd",
                            0.95,
                        )
                    )
        return entities

    def assign(self, assignment, time):
        job = assignment.object_id.rsplit("_", 1)[-1]
        if (
            job not in self.observers
            or assignment.object_id != f"parcel_{self.index}_{job}"
            or assignment.destination_id != f"receiver_{self.index}_{job}"
            or job in self.completed_jobs
        ):
            raise ValueError("Only a fresh calibrated own-workcell job is supported")
        self.current_job = job
        self.observer = self.observers[job]
        self.sensed = self.job_sensors[job]
        self.assignment = assignment
        self.finished = False
        self.object_goal = None
        self.state = {}
        if self.arm is not None:
            self.reset_started = time
            self.reset_joints = self.observer.proprio.qpos[29:36].copy()
            self.phase = "reset_arm"
        else:
            self.phase = "walk"
        self.phase_start = time

    def release_assignment(self):
        if not self.finished or self.phase != "complete" or self.arm.failed:
            return False
        self.completed_jobs.append(self.current_job)
        self.assignment = None
        self.finished = False
        return True

    def control(self, time):
        if self.transit_waypoints:
            root = np.asarray(self.sensed["root_position"][:2])
            goal = self.transit_waypoints[0]
            delta = goal - root
            quaternion = self.observer.proprio.qpos[3:7]
            yaw = math.atan2(
                2 * (quaternion[0] * quaternion[3] + quaternion[1] * quaternion[2]),
                1 - 2 * (quaternion[2] ** 2 + quaternion[3] ** 2),
            )
            rotation = np.array(
                [[math.cos(yaw), math.sin(yaw)], [-math.sin(yaw), math.cos(yaw)]]
            )
            self.command = np.r_[
                np.clip(rotation @ delta * 1.5, -0.35, 0.35),
                np.clip(-1.5 * yaw, -0.4, 0.4),
            ]
            obs = observation(
                self.observer.proprio, self.action, self.command, self.default
            )
            self.action = self.session.run(None, {"obs": obs[None]})[0][0]
            self.target = self.default + self.scale * self.action
            self.grip = 0.0
            self.phase = "back_out" if len(self.transit_waypoints) == 2 else "traverse"
            self.state = {
                "phase": self.phase,
                "job": self.current_job,
                "sensor_derived_waypoint": goal.tolist(),
                "waypoint_error_m": float(np.linalg.norm(delta)),
            }
            if np.linalg.norm(delta) < 0.06:
                self.transit_waypoints.pop(0)
                if not self.transit_waypoints:
                    self.phase, self.phase_start = "walk", time
            return
        if self.reset_started is not None:
            fraction = min(1.0, (time - self.reset_started) / 3.0)
            self.command = np.zeros(3)
            proprio = self.observer.proprio
            obs = observation(proprio, self.action, self.command, self.default)
            obs[33:40] = 0
            obs[62:69] = 0
            self.action = self.session.run(None, {"obs": obs[None]})[0][0]
            self.target = self.default + self.scale * self.action
            self.target[22:29] = (
                1 - fraction
            ) * self.reset_joints + fraction * self.default[22:29]
            self.arm = SimpleNamespace(arm_feedforward=np.zeros(7), failed=False)
            self.grip = 0.0
            self.phase = "reset_arm"
            self.state = {
                "phase": "reset_arm",
                "reset_progress": fraction,
                "job": self.current_job,
            }
            age = self.sensed.get("object_measurement_age_s")
            if fraction >= 1 and age is not None and age < 1:
                root = np.asarray(self.sensed["root_position"][:2])
                next_staging = np.asarray(self.sensed["object_position"][:2]) + [
                    -0.25,
                    0.25,
                ]
                back_x = min(root[0], next_staging[0]) - 0.30
                self.transit_waypoints = [
                    np.array([back_x, root[1]]),
                    np.array([back_x, next_staging[1]]),
                ]
                self.reset_started = None
                self.arm = None
                self.phase = "back_out"
                self.phase_start = time
            return
        # A completed robot holds its last arm command until another assignment.
        if self.assignment is None and self.completed_jobs:
            self.command = np.zeros(3)
            proprio = self.observer.proprio
            obs = observation(proprio, self.action, self.command, self.default)
            obs[33:40] = 0
            obs[62:69] = 0
            previous = self.target[22:29].copy()
            self.action = self.session.run(None, {"obs": obs[None]})[0][0]
            self.target = self.default + self.scale * self.action
            self.target[22:29] = previous
            self.grip = 0.0
            return
        super().control(time)
        self.state["job"] = self.current_job
