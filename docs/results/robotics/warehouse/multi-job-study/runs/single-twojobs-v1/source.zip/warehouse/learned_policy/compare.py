"""Compare matched fresh physical rollouts; never substitute offline BC loss."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..validate_v4 import validate
from .data import sha256


def compare(authored_root, learned_root, case_ids):
    rows = []
    for case in case_ids:
        paths = {
            "authored": authored_root / case / "probe.json",
            "learned": learned_root / case / "probe.json",
        }
        probes = {kind: json.loads(path.read_text()) for kind, path in paths.items()}
        teacher, learner = probes["authored"], probes["learned"]
        if teacher["scenario"] != learner["scenario"]:
            raise ValueError(f"Scenario mismatch for {case}")
        if teacher["initial_qpos_sha256"] != learner["initial_qpos_sha256"]:
            raise ValueError(f"Initial physics mismatch for {case}")
        if not all(p.get("full_horizon") for p in probes.values()):
            raise ValueError(f"Both policies must use a full physical horizon: {case}")
        for key in ("requested_duration_s", "mujoco_version", "render_backend"):
            if teacher[key] != learner[key]:
                raise ValueError(
                    f"Matched evaluation contract differs for {case}: {key}"
                )
        if set(teacher["evaluation"]) != set(learner["evaluation"]):
            raise ValueError(f"Robot set mismatch for {case}")
        validations = {kind: validate(path.parent) for kind, path in paths.items()}
        for robot in teacher["evaluation"]:
            metrics = {}
            for kind, p in probes.items():
                score = p["evaluation"][robot]
                metrics[kind] = {
                    key: score[key]
                    for key in (
                        "physical_success",
                        "controller_declared_completion",
                        "placement_xy_error_m",
                        "settled_seconds",
                        "minimum_root_height",
                    )
                }
                metrics[kind]["strict_current_settle_success"] = validations[kind][
                    "robots"
                ][robot]["strict_current_settle_success"]
                metrics[kind]["current_settled_seconds"] = validations[kind]["robots"][
                    robot
                ]["current_settled_seconds"]
                metrics[kind]["recorded_seconds"] = p["seconds"]
                metrics[kind]["termination_reason"] = p["termination_reason"]
            rows.append(
                {
                    "case": case,
                    "robot": robot,
                    "metrics": metrics,
                    "initial_qpos_sha256": teacher["initial_qpos_sha256"],
                    "probe_sha256": {
                        kind: sha256(path) for kind, path in paths.items()
                    },
                    "policy_sha256": learner["learned_policy_sha256"],
                }
            )
    wins = sum(
        row["metrics"]["authored"]["strict_current_settle_success"]
        and not row["metrics"]["learned"]["strict_current_settle_success"]
        for row in rows
    )
    losses = sum(
        row["metrics"]["learned"]["strict_current_settle_success"]
        and not row["metrics"]["authored"]["strict_current_settle_success"]
        for row in rows
    )
    return {
        "scope": "paired small-data recurrent BC versus authored sensor controller, shared frozen Unitree locomotion",
        "primary_metric": "independent strict_current_settle_success (one continuous second ending at final sample)",
        "rows": rows,
        "robot_trials": len(rows),
        "independent_physical_cases": len(case_ids),
        "authored_successes": sum(
            row["metrics"]["authored"]["strict_current_settle_success"] for row in rows
        ),
        "learned_successes": sum(
            row["metrics"]["learned"]["strict_current_settle_success"] for row in rows
        ),
        "authored_only_successes": wins,
        "learned_only_successes": losses,
        "statistical_unit": "physical case; co-simulated robots are not independent repeats",
        "limitation": "small frozen perturbation pilot, not a VLA/diffusion foundation-model benchmark or proof of general superiority",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--authored", type=Path, required=True)
    parser.add_argument("--learned", type=Path, required=True)
    parser.add_argument("--cases", nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.write_text(
        json.dumps(compare(args.authored, args.learned, args.cases), indent=2) + "\n"
    )
