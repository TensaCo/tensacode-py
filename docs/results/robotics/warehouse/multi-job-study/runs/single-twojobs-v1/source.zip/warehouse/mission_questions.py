"""Model query intents; answers come only from observed scene or scheduler records."""

from __future__ import annotations

import re

from .model_language import decode_request, ground_request, strict_json

QUESTION_PROMPT = """Translate a warehouse question into exactly one JSON query.
Never answer the question and never invent a cause or a location.
Forms:
{"where":"object reference"} for observed locations.
{"why_waiting":"explicit_robot_id"} for why a robot is waiting, idle, or blocked.
{"unsupported":"brief reason"} for all other questions or missing references.
Preserve explicit IDs. 'robot r1' means r1. 'the first robot' has no explicit ID.
References support colors and left of/right of/in/on relations; box/package/carton
means parcel. A query about a robot does not establish that robot exists.
Do not turn an action request into a question. No battery, mass, price, future
prediction, counterfactual, task-count, or unobserved-cause questions are supported.
Examples:
User: What's holding up robot r1?
{"why_waiting":"r1"}
User: Why hasn't r2 been assigned work?
{"why_waiting":"r2"}
User: Where did you observe parcel_0?
{"where":"parcel_0"}
User: Is r1 out of battery?
{"unsupported":"Battery questions are not supported"}
"""


def decode_question(raw: str) -> dict:
    value = strict_json(raw)
    if set(value) == {"why_waiting"}:
        robot_id = value["why_waiting"]
        if not isinstance(robot_id, str) or not re.fullmatch(
            r"[a-z0-9_-]{1,64}", robot_id
        ):
            raise ValueError("Lifecycle query requires an explicit bounded robot ID")
        return {"kind": "why_waiting", "robot_id": robot_id}
    request = decode_request(raw)
    if request["kind"] not in {"query", "unsupported"}:
        raise ValueError("Action proposals are not accepted by the question interface")
    return request


def answer_mission_question(request: dict, scene, now: float, scheduler=None) -> dict:
    """Read evidence only; never ask a model to supply the reason or answer text."""
    if request["kind"] == "why_waiting":
        if scheduler is None:
            return {"status": "unknown", "reason": "No scheduler evidence is available"}
        # explain consumes this controlled query, not original untrusted text.
        answer = scheduler.explain(f"Why is {request['robot_id']} waiting?")
        return {
            "query": {"kind": "why_waiting", "robot_id": request["robot_id"]},
            "answer_source": "scheduler_records",
            **answer,
        }
    return ground_request(request, scene, now)
