"""Explicit source-grounded session composition; generated claims remain hypotheses."""
from __future__ import annotations

import copy
from dataclasses import asdict, replace
import json
import math
from pathlib import Path

import torch

from .state import CognitiveState
from ...tools.cognition import Assessment, Evidence, Hypothesis, _text
from ..memory.learned import LearnedEpisodicMemory
from .policy import SelectionPolicy
from .locking import _ensure_lock, _model_locked


class CognitiveSession:
    """Persistent source evidence, revisable hypotheses and explicit abstention.

    Session snapshots contain data and policy only. Pass the Investigator model
    separately on restore. No generated hypothesis is inserted as evidence or an
    actual observation. Methods commit state only after successful validation.
    """
    def __init__(self, investigator, *, state=None, policy=None, memory=None):
        self.investigator = investigator
        _ensure_lock(investigator)
        self._state = state if state is not None else CognitiveState()
        if not isinstance(self._state, CognitiveState):
            raise ValueError('state must be CognitiveState')
        if isinstance(policy, dict):
            if set(policy) - {'min_support', 'max_contradiction', 'max_unknown'}:
                raise ValueError('invalid policy configuration')
            policy = SelectionPolicy(**policy)
        self.policy = policy if policy is not None else SelectionPolicy()
        if not isinstance(self.policy, SelectionPolicy):
            raise ValueError('policy must be SelectionPolicy')
        self.retrieval_k = 5
        if isinstance(memory, dict):
            if set(memory) - {'capacity', 'top_k'}:
                raise ValueError('invalid episodic memory configuration')
            self.retrieval_k = memory.get('top_k', 5)
            if type(self.retrieval_k) is not int or self.retrieval_k < 0:
                raise ValueError('top_k must be nonnegative')
            memory = LearnedEpisodicMemory(investigator, capacity=memory.get('capacity', 256))
        if memory is not None and (not isinstance(memory, LearnedEpisodicMemory) or memory.investigator is not investigator):
            raise ValueError('memory must use this session Investigator')
        self.memory = memory
        self._validate_memory_evidence(self._state.evidence)
        self._inactive_evidence = set()
        self._episode = 0
        self._active_evidence = {e.id: e.id for e in self._state.evidence}
        self._evidence_lineage = {e.id: (e.id,) for e in self._state.evidence}
        # Every session owns separate evidence but shares this immutable-model
        # content cache. Tensor versions/configuration still invalidate it.
        self._fingerprint = investigator._cognition_fingerprint
        self._observed_model = self._state.assessments[-1].model_provenance if self._state.assessments else None

    def _validate_memory_evidence(self, evidence):
        if self.memory is None:
            return
        for record in evidence:
            entry = self.memory.memory._entries.get(record.id)
            if entry is not None and entry.evidence != record:
                raise ValueError('remembered evidence conflicts with immutable session history')

    def _model_identity(self):
        return self._fingerprint([('investigator', self.investigator)], self.investigator.configuration())

    def invalidate_fingerprint(self):
        self._fingerprint.invalidate()
        if self.memory is not None:
            self.memory.invalidate_fingerprint()

    @property
    @_model_locked
    def state(self):
        if self._observed_model is not None:
            current = self._model_identity()
            if current != self._observed_model:
                self._state = replace(self._state, revision=self._state.revision + 1)
                self._observed_model = current
        return self._state

    @state.setter
    def state(self, value):
        if not isinstance(value, CognitiveState):
            raise ValueError('state must be CognitiveState')
        self._state = value

    @_model_locked
    def fork(self, *, copy_memory=True):
        memory = self.memory.fork() if copy_memory and self.memory is not None else self.memory
        result = CognitiveSession(self.investigator, state=self.state, policy=self.policy, memory=memory)
        result._active_evidence = dict(self._active_evidence)
        result._evidence_lineage = dict(self._evidence_lineage)
        result._inactive_evidence = set(self._inactive_evidence)
        result.retrieval_k = self.retrieval_k
        result._fingerprint = self._fingerprint
        result._observed_model = self._observed_model
        result._episode = self._episode
        return result

    @property
    def episode_id(self):
        return f'episode-{self._episode}'

    @_model_locked
    def new_episode(self):
        self.state = replace(self.state, revision=self.state.revision + 1,
                             hypotheses=(), assessments=(), selection=(), selection_revision=None,
                             goals=(), plans=())
        self._active_evidence = {}
        self._episode += 1
        return self.state

    @_model_locked
    def ingest(self, evidence):
        records = tuple(evidence)
        updated = self.state.add_evidence(records)
        self._validate_memory_evidence(updated.evidence)
        active = dict(self._active_evidence)
        lineage = dict(self._evidence_lineage)
        versions = {version for history in lineage.values() for version in history}
        for record in records:
            if record.id in self._inactive_evidence:
                raise ValueError('archived evidence cannot be reactivated implicitly')
            if record.id not in active:
                if record.id in versions and record.id not in lineage:
                    raise ValueError('revision record cannot become a separate logical source')
                active[record.id] = record.id
                lineage.setdefault(record.id, (record.id,))
        self.state, self._active_evidence = updated, active
        self._evidence_lineage = lineage
        return self.state

    def _resolve_logical_evidence(self, evidence_id):
        """Resolve explicit lineage; never infer relationships from user ID syntax."""
        _text(evidence_id, 'evidence_id')
        lineage = self._evidence_lineage.get(evidence_id)
        if lineage is not None:
            latest = lineage[-1]
            if latest in self._inactive_evidence:
                raise ValueError('logical evidence has been removed')
            source = next(e for e in self.state.evidence if e.id == latest)
            return source, lineage
        if any(evidence_id in history for history in self._evidence_lineage.values()):
            raise ValueError('revision requires the logical evidence id, not a version')
        if evidence_id in self._inactive_evidence:
            raise ValueError('archived evidence cannot be revised')
        source = next((e for e in self.state.evidence if e.id == evidence_id), None)
        entry = self.memory.memory._entries.get(evidence_id) if self.memory is not None else None
        if source is not None and entry is not None and source != entry.evidence:
            raise ValueError('evidence id conflicts with remembered content')
        if source is None and entry is not None:
            source = entry.evidence
        if source is None:
            raise ValueError('unknown logical evidence id')
        return source, (source.id,)

    @_model_locked
    def revise_evidence(self, evidence_id, text, source_id=None):
        old, history = self._resolve_logical_evidence(evidence_id)
        current = self.state
        new_id = f'{evidence_id}@{current.revision + 1}'
        if any(e.id == new_id for e in current.evidence) or (self.memory is not None and new_id in self.memory.memory._entries):
            raise ValueError('revision id conflict')
        replacement = Evidence(new_id, text, old.source_id if source_id is None else source_id)
        updated = current.add_evidence([old, replacement])
        memory = self.memory
        if memory is not None and old.id in memory.memory._entries:
            entry = memory.memory._entries[old.id]
            if entry.evidence != old:
                raise ValueError('evidence id conflicts with remembered content')
            memory = memory.fork()
            memory.remove(old.id)
            # Prior outcome feedback described old content, not this correction.
            memory.remember(replacement, episode_id=entry.episode_id,
                            question=entry.question, outcome='')
        active = dict(self._active_evidence); active[evidence_id] = replacement.id
        lineage = dict(self._evidence_lineage); lineage[evidence_id] = (*history, replacement.id)
        self.state, self._active_evidence = updated, active
        self._evidence_lineage = lineage
        self._inactive_evidence = self._inactive_evidence | {old.id}
        self.memory = memory
        return self.state

    @_model_locked
    def remove_evidence(self, evidence_id):
        old, history = self._resolve_logical_evidence(evidence_id)
        updated = self.state.add_evidence([old])
        updated = replace(updated, revision=updated.revision + 1)
        active = dict(self._active_evidence); active.pop(evidence_id, None)
        lineage = dict(self._evidence_lineage); lineage[evidence_id] = history
        self.state, self._active_evidence = updated, active
        self._evidence_lineage = lineage
        self._inactive_evidence = self._inactive_evidence | {old.id}
        return self.state

    @property
    def active_evidence(self):
        by_id = {e.id: e for e in self.state.evidence}
        return tuple(by_id[key] for key in self._active_evidence.values())

    @_model_locked
    def investigate(self, question, *, hypotheses=None, count=3, episode_id=None, conversation_context=None):
        _text(question, 'question')
        from ..proposals import conversation_context as validate_context, conversation_block
        dialogue = validate_context({'conversation_context': [] if conversation_context is None else conversation_context})
        retrieval_query = question
        if self.memory is not None and dialogue:
            retrieval_query = conversation_block(dialogue) + 'Current question: ' + question
            encoder = getattr(self.investigator, 'episodic_encoder', None)
            encoder = encoder if encoder is not None else self.investigator.rank
            if encoder.tokenizer is not None:
                length = len(encoder.tokenizer(retrieval_query)['input_ids'])
            else:
                import re
                length = len(re.findall(r'\w+|[^\w\s]', retrieval_query.casefold()))
            if length > encoder.config['max_tokens']:
                raise ValueError('Conversation and current question exceed retrieval token budget')
        evidence = self.active_evidence
        hits = ()
        working = self.state
        if self.memory is not None:
            # Request the bounded index before filtering archived/active sources,
            # so obsolete nearest neighbors cannot crowd out eligible sources.
            retrieved = self.memory.retrieve(retrieval_query, k=self.memory.memory.capacity, exclude_episode_id=self.episode_id if episode_id is None else episode_id)
            active_ids = {e.id for e in evidence}
            hits = tuple(hit for hit in retrieved if hit.evidence.id not in self._inactive_evidence and hit.evidence.id not in active_ids)[:self.retrieval_k]
            working = working.add_evidence([hit.evidence for hit in hits])
            evidence = evidence + tuple(hit.evidence for hit in hits)
        # Investigator requires unique source IDs. Immutable evidence IDs provide
        # that identity even when several passages cite the same document.
        inputs = {'question': question, 'evidence': [{'source_id': e.id, 'text': e.text} for e in evidence]}
        if conversation_context is not None:
            inputs['conversation_context'] = dialogue
        if hypotheses is not None:
            inputs['hypotheses'] = copy.deepcopy(hypotheses)
        modes = [(module, module.training) for module in self.investigator.rank.modules()]
        try:
            self.investigator.rank.eval()
            self.investigator.rank.clear_encoding_cache()
            with torch.no_grad():
                result = self.investigator.investigate(inputs, count=count)
        finally:
            for module, training in modes:
                module.training = training
        # Verification may invalidate stale calibration buffers during inference.
        provenance = self._model_identity()
        proposals = [Hypothesis(candidate['id'], candidate['text'],
                                origin='generated' if hypotheses is None else 'supplied',
                                model_provenance=provenance if hypotheses is None else 'caller-supplied')
                     for candidate in result['candidates']]
        updated = working.add_hypotheses(proposals)
        assessments, accepted = [], []
        by_id = {e.id: e for e in evidence}
        candidates = copy.deepcopy(result['candidates'])
        for candidate in candidates:
            checks = candidate['verifications']
            if len(checks) != len(evidence) or {check['source_id'] for check in checks} != set(by_id):
                raise ValueError('verification sources must match active evidence exactly')
            candidate['accepted_by_policy'] = self.policy.accepts_verification(
                candidate, list(by_id), scope=self.investigator.config['verification_scope'])
            for check in checks:
                evidence_id = check['source_id']
                distribution = check['distribution']
                assessments.append(Assessment(evidence_id, candidate['id'], distribution, provenance))
                check['evidence_id'] = evidence_id
                check['source_id'] = by_id[evidence_id].source_id
            truncated = any(check.get('input_truncated', False) for check in checks)
            joint = candidate.get('joint_verification')
            if joint is not None:
                truncated = truncated or joint.get('input_truncated', False)
                joint['evidence_ids'] = list(joint['source_ids'])
                joint['source_ids'] = [by_id[evidence_id].source_id for evidence_id in joint['evidence_ids']]
            candidate['verification_coverage'] = ('truncated; abstention required' if truncated else
                'complete joint premise and supplied pairs' if joint is not None else 'complete supplied pairs')
            candidate['epistemic_status'] = 'hypothesis'
            score = candidate['predicted_score']
            if type(score) not in (int, float) or not math.isfinite(score):
                raise ValueError('candidate rank scores must be finite')
            if candidate['accepted_by_policy']:
                accepted.append(candidate)
        updated = updated.assess(assessments)
        selected = max(accepted, key=lambda candidate: candidate['predicted_score'])['id'] if accepted else None
        updated = updated.select([selected] if selected is not None else [])
        receipt = {'question': question, 'selected_id': selected, 'abstained': selected is None,
                   'candidates': candidates, 'evidence': [asdict(e) for e in evidence],
                   'retrieval': [asdict(hit) for hit in hits],
                   'retrieval_encoder': self.memory.metadata if self.memory is not None else None,
                   'state_revision': updated.revision, 'policy': self.policy.receipt(scope=self.investigator.config['verification_scope']),
                   'verification_scope': self.investigator.config['verification_scope'],
                   'model_provenance': provenance,
                   'semantics': 'Generated and supplied candidates remain hypotheses; selection is authored screening of model scores, not truth.'}
        if dialogue:
            receipt['conversation_context'] = dialogue
            receipt['retrieval_query'] = retrieval_query if self.memory is not None else None
        lineage = dict(self._evidence_lineage)
        known_versions = {version for history in lineage.values() for version in history}
        for hit in hits:
            if hit.evidence.id not in known_versions:
                lineage[hit.evidence.id] = (hit.evidence.id,)
        self.state = updated
        self._evidence_lineage = lineage
        self._observed_model = provenance
        return receipt

    @_model_locked
    def remember(self, evidence_id, *, episode_id=None, question='', outcome=''):
        if self.memory is None:
            raise ValueError('episodic memory is not configured')
        resolved = self._evidence_lineage[evidence_id][-1] if evidence_id in self._evidence_lineage else evidence_id
        if resolved in self._inactive_evidence:
            raise ValueError('archived evidence cannot be remembered')
        source = next((e for e in self.state.evidence if e.id == resolved), None)
        if source is None:
            raise ValueError('unknown evidence id')
        return self.memory.remember(source, episode_id=self.episode_id if episode_id is None else episode_id, question=question, outcome=outcome)

    @_model_locked
    def retrieve(self, question, *, k=5, exclude_episode_id=None):
        if self.memory is None:
            raise ValueError('episodic memory is not configured')
        if type(k) is not int or k < 0:
            raise ValueError('k must be nonnegative')
        hits = self.memory.retrieve(question, k=self.memory.memory.capacity,
                                    exclude_episode_id=exclude_episode_id)
        return tuple(hit for hit in hits if hit.evidence.id not in self._inactive_evidence)[:k]

    @_model_locked
    def snapshot(self):
        return {'schema_version': 2, 'state': self.state.to_dict(),
                'evidence_lineage': {key: list(history) for key, history in self._evidence_lineage.items()},
                'active_evidence': dict(self._active_evidence), 'policy': asdict(self.policy),
                'inactive_evidence': sorted(self._inactive_evidence), 'retrieval_k': self.retrieval_k,
                'memory': self.memory.snapshot() if self.memory is not None else None,
                'model_provenance': self._observed_model, 'episode': self._episode}

    @classmethod
    def from_snapshot(cls, snapshot, *, investigator, memory=None):
        if not isinstance(snapshot, dict) or set(snapshot) != {'schema_version','state','active_evidence','evidence_lineage','policy','inactive_evidence','retrieval_k','memory','model_provenance','episode'} or type(snapshot['schema_version']) is not int or snapshot['schema_version'] != 2:
            raise ValueError('unsupported cognitive session schema')
        policy = snapshot['policy']
        if not isinstance(policy, dict) or set(policy) != {'min_support','max_contradiction','max_unknown'}:
            raise ValueError('invalid policy schema')
        state = CognitiveState.from_dict(snapshot['state'])
        active = snapshot['active_evidence']
        ids = {e.id for e in state.evidence}
        if not isinstance(active, dict) or any(not isinstance(k,str) or not k or k not in ids or not isinstance(v,str) or v not in ids for k,v in active.items()) or len(set(active.values())) != len(active):
            raise ValueError('invalid active evidence references')
        inactive = snapshot['inactive_evidence']
        if not isinstance(inactive, list) or any(not isinstance(i,str) or i not in ids for i in inactive) or len(set(inactive)) != len(inactive) or set(inactive) & set(active.values()):
            raise ValueError('invalid archived evidence references')
        lineage = snapshot['evidence_lineage']
        if not isinstance(lineage, dict):
            raise ValueError('invalid evidence lineage')
        seen = set()
        for root, history in lineage.items():
            if (not isinstance(root, str) or root not in ids or not isinstance(history, list)
                    or not history or history[0] != root
                    or any(not isinstance(version, str) or version not in ids for version in history)
                    or len(set(history)) != len(history) or seen.intersection(history)
                    or any(version not in inactive for version in history[:-1])):
                raise ValueError('invalid evidence lineage')
            seen.update(history)
        if seen != ids:
            raise ValueError('evidence lineage must cover every historical record')
        if any(root not in lineage or lineage[root][-1] != latest for root, latest in active.items()):
            raise ValueError('active evidence conflicts with lineage')
        retrieval_k = snapshot['retrieval_k']
        if type(retrieval_k) is not int or retrieval_k < 0:
            raise ValueError('invalid retrieval limit')
        if snapshot['memory'] is not None:
            if memory is not None:
                raise ValueError('snapshot already supplies episodic memory')
            memory = LearnedEpisodicMemory.from_snapshot(snapshot['memory'], investigator=investigator)
        result = cls(investigator, state=state, policy=SelectionPolicy(**policy), memory=memory)
        result._active_evidence = dict(active)
        result._evidence_lineage = {root: tuple(history) for root, history in lineage.items()}
        result._inactive_evidence = set(inactive)
        result.retrieval_k = retrieval_k
        provenance = snapshot['model_provenance']
        if provenance is not None and (not isinstance(provenance,str) or not provenance):
            raise ValueError('invalid model provenance')
        if state.assessments and provenance is None:
            raise ValueError('assessed session requires model provenance')
        if type(snapshot['episode']) is not int or snapshot['episode'] < 0:
            raise ValueError('invalid episode counter')
        result._episode = snapshot['episode']
        result._observed_model = provenance
        # Trigger weight compatibility invalidation before exposing restored state.
        result.state
        return result

    def save(self, path):
        Path(path).write_text(json.dumps(self.snapshot(), allow_nan=False, indent=2), encoding='utf-8')

    @classmethod
    def load(cls, path, *, investigator, memory=None):
        def pairs(items):
            result = {}
            for key, value in items:
                if key in result:
                    raise ValueError('duplicate JSON key')
                result[key] = value
            return result
        return cls.from_snapshot(json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs),
                                 investigator=investigator, memory=memory)
