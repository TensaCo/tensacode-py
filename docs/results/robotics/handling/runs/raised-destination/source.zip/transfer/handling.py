"""Visually targeted pickup, transport, placement and withdrawal for G1.

The destination is a calibrated-color 20 cm support observed through RGB-D.
No simulator target pose or object/world label enters this controller.
"""

from __future__ import annotations

import numpy as np
from planning import GuardedManipulation
from scipy.spatial.transform import Rotation


class PickPlace(GuardedManipulation):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.destination = None
        self.transport_started = False

    def step(self, estimated, sensors, time, dt=0.02):
        if not self.transport_started:
            result = super().step(estimated, sensors, time, dt)
            if self.phase == "hold" and not self.failed:
                self.transport_started = True
                self.transition("locate_destination", time, "payload_lifted")
                result[-1]["phase"] = self.phase
            return result
        if self.phase == "failed":
            # Shared failure policy opens and attempts to retract; no hidden retry.
            return super().step(estimated, sensors, time, dt)
        hand = estimated.site_xpos[self.ik.site]
        rotation = estimated.site_xmat[self.ik.site].reshape(3, 3)
        elapsed = time - self.phase_started
        tactile = np.asarray(sensors.get("pad_force_n", [0.0, 0.0])) > 0.25
        destination = sensors.get("destination_position")
        age = sensors.get("destination_measurement_age_s")
        if (
            self.phase == "locate_destination"
            and destination is not None
            and age is not None
            and age < 1.0
        ):
            self.destination = np.asarray(destination).copy()
            self.ik.additional_supports = [self.destination.copy()]
            self.transition("transport", time, "fresh_rgbd_destination")
        target = self.command.copy()
        if self.destination is not None:
            target = (
                self.destination
                + {
                    "transport": [0, 0, 0.20],
                    "lower": [0, 0, 0.034],
                    "open": [0, 0, 0.034],
                    "withdraw": [-0.08, 0, 0.19],
                    "complete": [-0.08, 0, 0.19],
                    "locate_destination": [0, 0, 0.20],
                }[self.phase]
            )
        tracking = float(np.linalg.norm(hand - self.command))
        orientation = float(
            Rotation.from_matrix(self.rotation @ rotation.T).magnitude()
        )
        speed = 0.02 if self.phase == "lower" else 0.04
        tracking_limit = 0.005 if self.phase == "lower" else 0.012
        if tracking < tracking_limit and orientation < 0.15:
            delta = target - self.command
            self.command += delta * min(
                1.0, speed * dt / max(np.linalg.norm(delta), 1e-12)
            )
        error = float(np.linalg.norm(hand - target))
        self.stable = self.stable + dt if error < 0.008 and orientation < 0.10 else 0.0
        if self.phase == "transport" and self.stable > 0.30:
            self.transition("lower", time, "above_receiving_surface")
        elif self.phase == "lower" and self.stable > 0.40:
            self.transition("open", time, "placement_pose_converged")
        elif self.phase == "open" and elapsed > 0.8 and not tactile.any():
            self.transition("withdraw", time, "tactile_release")
        elif self.phase == "withdraw" and self.stable > 0.3:
            self.transition("complete", time, "hand_withdrawn")
        elif self.phase == "complete" and elapsed > 2.0:
            self.done = True
        must_hold = self.phase in ("locate_destination", "transport") or (
            self.phase == "lower" and error > 0.025
        )
        if must_hold:
            self.contact_lost_seconds = (
                0.0 if tactile.all() else self.contact_lost_seconds + dt
            )
            if self.contact_lost_seconds > 0.30:
                self.failed = True
                self.transition("failed", time, "payload_contact_lost")
        if time - self.phase_started > 22.0 and self.phase not in ("complete", "failed"):
            self.failed = True
            self.transition("failed", time, "handling_phase_timeout")
        grip = (
            0.028 if self.phase in ("locate_destination", "transport", "lower") else 0.0
        )
        q, diagnostics = self.ik.solve(
            estimated, self.command, self.rotation, self.previous, self.anchor, True
        )
        self.previous = q.copy()
        diagnostics.update(
            phase=self.phase,
            tracking_error_m=tracking,
            orientation_error_rad=orientation,
            target_error_m=error,
            transition_reason=self.transition_reason,
            pad_force_n=sensors.get("pad_force_n", [0.0, 0.0]),
            destination_position=None
            if self.destination is None
            else self.destination.tolist(),
            destination_measurement_age_s=age,
            failed=self.failed,
        )
        return q, self.command.copy(), self.rotation.copy(), grip, diagnostics
